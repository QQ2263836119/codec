
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <vector>
#include "ArithmeticCoder.hpp"
#include "BitIoStream.hpp"
#include "GmmTable.h"

using std::uint32_t;

int main(int argc, char *argv[]) {
	// Handle command line arguments
	if (argc != 4) {
		std::cerr << "Usage: " << argv[0] << " InputFile EncFile DecFile" << std::endl;
		return EXIT_FAILURE;
	}
	char *inputFile  = argv[2];
	char *outputFile = argv[3];
	
	//初始化GMM，要和编码器那边的GMM一致
	double probs[]={0.1,0.15,0.25,0.25,0.15,0.1};
	double means[]={0,10000,16384,32768,43690,65536};
	double stds[] ={5000,15000,20000,40000,15000,5000};
	uint32_t freqs_resolution = 1e9;
	//初始化混合高斯模型
	Gmm gmm =initGmm(probs,means,stds,6,freqs_resolution);

	uint16_t low_bound=0;
	uint16_t high_bound=65535;

	bool ans=decoding(gmm,low_bound,high_bound,inputFile,outputFile);

	return 0;
}
